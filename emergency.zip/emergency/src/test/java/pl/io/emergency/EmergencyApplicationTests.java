package pl.io.emergency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmergencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
